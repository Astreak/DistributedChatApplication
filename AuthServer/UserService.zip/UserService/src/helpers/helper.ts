import client from "../config/connectDB";

var checkUser = (req: any, res: any, next: any) => {
   const email: string = req.body.email;
   client.query('SELECT Id from users WHERE email = $1', [email])
      .then((d) => {
         if (d.rows.length == 0) res.locals.userExists = false;
         else res.locals.userExists = true;
         next();
      }).catch((err) => {
         console.log(`Error getting record`);
         next();
      });
   
}
export { checkUser };