import express from 'express';
import { signIn } from '../controllers/signInController';
import { checkUser } from '../helpers/helper';
var signInRoute = express.Router();
signInRoute.post('/api/signIn/',checkUser,signIn);
export  { signInRoute };
