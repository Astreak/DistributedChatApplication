import client from "../config/connectDB";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import Randomstring from 'randomstring';
var signIn = (req: any, res: any) => {
   const email = req.body.email;
   const password = req.body.password;
   if (res.locals.userExists === false) {
      res.status(401).send({
         'message': 'User doesn"t exists ',
         'status': 401
      });
      return;
   }
   client.query('SELECT Id, firstname, lastname, phone, email, password from users WHERE email = $1', [email])
      .then((d) => {
         const userData = d.rows[0];
         bcrypt.compare(password, userData.password)
            .then((result) => {
               if (result == false) {
                  res.status(403).send({ "msg": "Wrong Password" });
                  return;
               } else {
                  let randomS: string = Randomstring.generate(55);
                  const token = jwt.sign({
                     email: userData.email,
                     username: userData.username
                  }, randomS, { expiresIn: '1hr' });
                  delete userData['password'];
                  res.status(201).send({
                     'token': token,
                     'userId': userData.username,
                     'message': 'Successfull login',
                     'status': 201,
                     'data': userData
                  });
               }
            }).catch((ex) => {
               console.log(`Error  in logging in ${ex}`);
               res.send(501).send({
                  'message': 'Some Error occurred',
                  'status': 501
               });
            });
      }).catch((e) => {
         console.log(`Error: ${e}`);
         res.send(501).send({
            'message': 'Some Error occurred',
            'status': 501
         });
      });
}
export { signIn };