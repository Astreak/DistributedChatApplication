import express from 'express';
import os from 'os';
import cluster from 'cluster';
import { signUpRoute } from './src/routes/userSignUp';
import { signInRoute } from './src/routes/userLogin';
import cors from 'cors';
import 'dotenv/config';
const app = express();
app.use(express.json());
app.use(cors());
const PORT = process.env.PORT ||  '3000';
app.get("/", (req: any, res: any) => {
   for (let i = 0; i <= 1e9; i++);
   res.status(201).send({
      'message': `Welcome to User Service of the chat app ${process.pid}`,
      'status': 201
   });
});
const cpuCounts = Math.min(os.cpus().length, 4) ;
app.use(signInRoute);
app.use(signUpRoute);
if (cluster.isPrimary) {
   for (let i = 0; i < cpuCounts; i++) {
      cluster.fork();
   }
} else {
   app.listen(PORT, () => {
      console.log(`[+] Server Connected on PORT: ${PORT} and processID : ${process.pid}`);
   });
}

